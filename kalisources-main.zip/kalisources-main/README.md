# kalisources
Kali Sources For Easy Setup
# Downloand&Run
```
$ git clone https://github.com/lastpingu/kalisources.git
$ cd kalisources
$ chmod +x kalisources
$ sudo ./kalisources
```
* kullanımı çok kolaydır yetkilendirdikten sonra sadece `sudo ./kalisources` yeterli.
* yardım almak için `./kalisources -h`
